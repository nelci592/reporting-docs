﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            var model = new MyModel();
            model.MyList = GetData();

            return View("ReportViewerView1", model);
        }

        [HttpPost]
        public ActionResult Index(MyModel model)
        {
            var addValue = "new entry";
            //save in data source - submit changes
            SaveData(addValue);
            return RedirectToAction("Index");
        }

        //some data retrieval method in the MVC COntext
        List<MyDataObject> GetData()
        {
            var data = new List<MyDataObject>();

            using (StreamReader sr = new StreamReader(@"D:\Samples\Demo\Demo\DATASOURCE.CSV"))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    data.Add(new Models.MyDataObject { Column1 = line });
                }
            }

            return data;
        }

        //some CRUD immitation
        void SaveData(string addValue)
        {
            using (StreamWriter sw = new StreamWriter(@"D:\Samples\Demo\Demo\DATASOURCE.CSV", true))
            {

                sw.WriteLine(sw.NewLine + addValue);
            }
        }
    }
}