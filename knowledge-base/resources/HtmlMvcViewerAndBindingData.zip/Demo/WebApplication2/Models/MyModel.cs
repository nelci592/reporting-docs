﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication2.Models
{
    public class MyModel
    {
        public List<MyDataObject> MyList { get; set; }
    }

    public class MyDataObject
    {
        public string Column1 { get; set; }
    }
}