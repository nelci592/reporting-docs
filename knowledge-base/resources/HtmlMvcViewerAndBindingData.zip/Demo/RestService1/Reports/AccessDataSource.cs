﻿using System.Collections.Generic;
using System.IO;

namespace RestService1.Reports
{
    public class MyDataAccesLayer
    {
     public   List<string> GetDataFromSource()
        {
            var data = new List<string>();

            using (StreamReader sr = new StreamReader(@"D:\Samples\Demo\Demo\DATASOURCE.CSV"))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    data.Add(line);
                }
            }

            return data;
        }
    }
}